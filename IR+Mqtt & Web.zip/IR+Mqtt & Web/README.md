## Send mqtt-server to your Raspberry Pi

Then run the following commands :
python -m venv venv
source venv/bin/activate
pip3 install paho-mqtt mqtt
python3 mqttServer.py

If pip or python or both aren't installed, run the commands listed at the address :
https://github.com/RipYep/Escape-Game/edit/main/README.md#installation-de-ir-keytable-evdev-et-python-sur-le-raspberry
