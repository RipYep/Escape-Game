#!/bin/bash

# Ouvre l'adresse dans le navigateur par défaut
xdg-open http://csg-ceo.fr/escape-game/ceo-account.html

# Pause pour laisser le navigateur s'ouvrir
sleep 0.5

# Ouvre l'explorateur de fichiers à /etc/CEO/
xdg-open "/etc/CEO/"
